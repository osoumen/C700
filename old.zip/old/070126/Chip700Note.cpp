/*
 *  Chip700Note.cpp
 *  Chip700
 *
 *  Created by 開発用 on 06/09/06.
 *  Copyright 2006 Vermicelli Magic. All rights reserved.
 *
 */

#include "Chip700.h"
#include "Chip700Note.h"
#include "gauss.h"

#define filter1(a1)	(( a1 >> 1 ) + ( ( -a1 ) >> 5 ))
#define filter2(a1,a2)	(a1 \
						 + ( ( -( a1 + ( a1 >> 1 ) ) ) >> 5 ) \
						 - ( a2 >> 1 ) + ( a2 >> 5 ))
#define filter3(a1,a2)	(a1 \
						 + ( ( -( a1 + ( a1 << 2 ) \
								  + ( a1 << 3 ) ) ) >> 7 ) \
						 - ( a2 >> 1 ) \
						 + ( ( a2 + ( a2 >> 1 ) ) >> 4 ))

const float onepi = 3.14159265358979;

static const int	*G1 = &gauss[256];
static const int	*G2 = &gauss[512];
static const int	*G3 = &gauss[255];
static const int	*G4 = &gauss[-1];

static const int	CNT_INIT = 0x7800;
static const int	ENVCNT[32]
= {
    0x0000, 0x000F, 0x0014, 0x0018, 0x001E, 0x0028, 0x0030, 0x003C,
    0x0050, 0x0060, 0x0078, 0x00A0, 0x00C0, 0x00F0, 0x0140, 0x0180,
    0x01E0, 0x0280, 0x0300, 0x03C0, 0x0500, 0x0600, 0x0780, 0x0A00,
    0x0C00, 0x0F00, 0x1400, 0x1800, 0x1E00, 0x2800, 0x3C00, 0x7800
};

static const int	VELOCITY_CURB[128]
= {
	0x000, 0x001, 0x001, 0x001, 0x001, 0x001, 0x001, 0x001, 0x001, 0x001, 0x001, 0x001, 0x001, 0x002, 0x002, 0x003,
	0x004, 0x004, 0x005, 0x006, 0x007, 0x009, 0x00a, 0x00c, 0x00d, 0x00f, 0x011, 0x013, 0x015, 0x018, 0x01a, 0x01d,
	0x020, 0x023, 0x027, 0x02a, 0x02e, 0x032, 0x036, 0x03b, 0x03f, 0x044, 0x04a, 0x04f, 0x055, 0x05b, 0x061, 0x067,
	0x06e, 0x075, 0x07c, 0x084, 0x08c, 0x094, 0x09d, 0x0a6, 0x0af, 0x0b9, 0x0c2, 0x0cd, 0x0d7, 0x0e2, 0x0ee, 0x0f9,
	0x105, 0x112, 0x11f, 0x12c, 0x13a, 0x148, 0x156, 0x165, 0x174, 0x184, 0x194, 0x1a5, 0x1b6, 0x1c8, 0x1da, 0x1ec,
	0x1ff, 0x213, 0x226, 0x23b, 0x250, 0x265, 0x27b, 0x292, 0x2a9, 0x2c0, 0x2d8, 0x2f1, 0x30a, 0x323, 0x33e, 0x358,
	0x374, 0x390, 0x3ac, 0x3c9, 0x3e7, 0x405, 0x424, 0x443, 0x464, 0x484, 0x4a6, 0x4c8, 0x4ea, 0x50e, 0x532, 0x556,
	0x57b, 0x5a1, 0x5c8, 0x5ef, 0x617, 0x640, 0x669, 0x694, 0x6be, 0x6ea, 0x716, 0x743, 0x771, 0x79f, 0x7cf, 0x7ff
};

static const int sinctable[] = {
	0, -7,  27, -71,  142, -227,  299,  32439,   299,  -227,  142,  -71,  27,  -7,  0,  0,
	0,  0,  -5,  36, -142,  450, -1439, 32224,  2302,  -974,  455, -190,  64, -15,  2,  0,
	0,  6, -33, 128, -391, 1042, -2894, 31584,  4540, -1765,  786, -318, 105, -25,  3,  0,
	0, 10, -55, 204, -597, 1533, -4056, 30535,  6977, -2573, 1121, -449, 148, -36,  5,  0,
	-1, 13, -71, 261, -757, 1916, -4922, 29105,  9568, -3366, 1448, -578, 191, -47,  7,  0,
	-1, 15, -81, 300, -870, 2185, -5498, 27328, 12263, -4109, 1749, -698, 232, -58,  9,  0,
	-1, 15, -86, 322, -936, 2343, -5800, 25249, 15006, -4765, 2011, -802, 269, -68, 10,  0,
	-1, 15, -87, 328, -957, 2394, -5849, 22920, 17738, -5298, 2215, -885, 299, -77, 12,  0,
	0, 14, -83, 319, -938, 2347, -5671, 20396, 20396, -5671, 2347, -938, 319, -83, 14,  0,
	0, 12, -77, 299, -885, 2215, -5298, 17738, 22920, -5849, 2394, -957, 328, -87, 15, -1,
	0, 10, -68, 269, -802, 2011, -4765, 15006, 25249, -5800, 2343, -936, 322, -86, 15, -1,
	0,  9, -58, 232, -698, 1749, -4109, 12263, 27328, -5498, 2185, -870, 300, -81, 15, -1,
	0,  7, -47, 191, -578, 1448, -3366,  9568, 29105, -4922, 1916, -757, 261, -71, 13, -1,
	0,  5, -36, 148, -449, 1121, -2573,  6977, 30535, -4056, 1533, -597, 204, -55, 10,  0,
	0,  3, -25, 105, -318,  786, -1765,  4540, 31584, -2894, 1042, -391, 128, -33,  6,  0,
	0,  2, -15,  64, -190,  455,  -974,  2302, 32224, -1439,  450, -142,  36,  -5,  0,  0,
	0,  0,  -7,  27,  -71,  142,  -227,   299, 32439,   299, -227,  142, -71,  27, -7,  0
};

static unsigned char silence_brr[] = {
	0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

void Chip700Note::Reset()
{
	SynthNote::Reset();

	mInternalClock=32000;
	for (int i=0; i<16; i++)
		mProcessbuf[i]=0;
	mProcessFrac=0;
	mProcessbufPtr=0;
	
	mSmp1=0;
	mSmp2=0;
	mSampbuf[0]=0;
	mSampbuf[1]=0;
	mSampbuf[2]=0;
	mSampbuf[3]=0;
	
	mOnCnt = -1;
	mOffCnt = -1;
	
	brrdata = silence_brr;
	mLoopPoint = 0;
	mLoop = false;
	
	mFRFlag = false;
	
	mPitch = 0;
	
	mVibPhase = 0.0f;
	mMemPtr = 0;
	mHeaderCnt = 0;
	mHalf = 0;
	mEnvx = 0;
	mEnd = 0;
	mSampptr = 0;
	mMixfrac=0;
	mEnvcnt = CNT_INIT;
	mEnvstate = RELEASE;
}

void Chip700Note::Attack(const MusicDeviceNoteParams &inParams)
{
	Chip700		*synth;
	VoiceParams		vp;
	
	mParam = inParams;

	synth = (Chip700*)GetAudioUnit();
	if (GetGlobalParameter(kParam_drummode)) {
		vp = synth->getMappedVP(inParams.mPitch);
	}
	else {
		vp = synth->getVP(GetGlobalParameter(kParam_program));
	}
	
	if (vp.brr.data) {
		mOnCnt = GetRelativeStartFrame();
	}
	else {
		mEnvx = 0;
		brrdata = silence_brr;
		mEnvstate = RELEASE;
	}
}

void Chip700Note::Release(UInt32 inFrame)
{
	SynthNote::Release(inFrame);
	mOffCnt = inFrame;
	mFRFlag = false;
}

void Chip700Note::FastRelease(UInt32 inFrame)
{
	SynthNote::Release(inFrame);
	mOffCnt = inFrame;
	mFRFlag = true;
}

void Chip700Note::Kill(UInt32 inFrame)
{
	SynthNote::Kill(inFrame);
	mEnvstate = FASTRELEASE;
}

void Chip700Note::KeyOn(void)
{
	Chip700		*synth;
	VoiceParams		vp;
	
	//ベロシティの取得
	if (GetGlobalParameter(kParam_velocity) != 0.) {
		mVelo = mParam.mVelocity;
		mVelo = VELOCITY_CURB[mVelo];
	}
	else {
		mVelo=VELOCITY_CURB[127];
	}
	
	synth = (Chip700*)GetAudioUnit();
	if (GetGlobalParameter(kParam_drummode)) {
		vp = synth->getMappedVP(mParam.mPitch);
	}
	else {
		vp = synth->getVP(GetGlobalParameter(kParam_program));
	}
	
	brrdata = vp.brr.data;
	mLoopPoint = vp.lp;
	mLoop = vp.loop;
	
	//中心周波数の算出
	mPitch = pow(2., (mParam.mPitch - vp.basekey) / 12.)/mInternalClock*vp.rate*4096 + 0.5;
	
	vol_l=vp.volL;
	vol_r=vp.volR;
	ar=vp.ar;
	dr=vp.dr;
	sl=vp.sl;
	sr=vp.sr;
	
	mVibPhase = 0.0f;
	mMemPtr = 0;
	mHeaderCnt = 0;
	mHalf = 0;
	mEnvx = 0;
	mEnd = 0;
	mSampptr = 0;
	mMixfrac = 3 * 4096;
	mEnvcnt = CNT_INIT;
	mEnvstate = ATTACK;
}

OSStatus Chip700Note::Render(UInt32 inNumFrames, AudioBufferList& inBufferList)
{
	float			*left, *right;
	int             envx;
	int				outx;
	int				vl,vr;
	int				reg_vol_l,reg_vol_r,reg_ar,reg_dr,reg_sl,reg_sr;
	bool			reg_pmod;
	float			vibfreq;
	int				vibdepth;
	float			vibdepth2;
	float			pbrange;
	int				clipper;
	int				pitch,pb;
	int				procstep=(32000*21168)/SampleRate();
	UInt32			endFrame = 0xFFFFFFFF;
	
	//バッファの確保
	{
		int numChans = inBufferList.mNumberBuffers;
		if (numChans > 2) return -1;
		left = (float*)inBufferList.mBuffers[0].mData;
		right = numChans==2 ? (float*)inBufferList.mBuffers[1].mData : 0;
	}

	//パラメータの読み込み
	reg_vol_l = vol_l;
	reg_vol_r = vol_r;
	reg_ar = ar;
	reg_dr = dr;
	reg_sl = sl;
	reg_sr = sr;
	vibfreq = GetGlobalParameter(kParam_vibrate)*((onepi*2)/mInternalClock);
	vibdepth = GetGlobalParameter(kParam_vibdepth);
	vibdepth2 = GetGlobalParameter(kParam_vibdepth2)/2;
	reg_pmod = vibdepth > 0 ? true:false;
	clipper = GetGlobalParameter(kParam_clipnoise)==0 ? 0:1;
	pbrange = GetGlobalParameter(kParam_bendrange)/2.0;
	
	pb = (pow(2., (PitchBend()*pbrange) / 12.) - 1.0)*mPitch;
	
	//メイン処理
	for (UInt32 frame=0; frame<inNumFrames; ++frame)
	{
		if (mOnCnt >= 0) {
			mOnCnt--;
			if (mOnCnt < 0) {
				KeyOn();
				reg_vol_l=vol_l;
				reg_vol_r=vol_r;
				reg_ar=ar;
				reg_dr=dr;
				reg_sl=sl;
				reg_sr=sr;

				if (endFrame != 0xFFFFFFFF) endFrame = 0xFFFFFFFF;
			}
		}
		
		if (mOffCnt >= 0) {
			mOffCnt--;
			if (mOffCnt < 0) {
				if (mFRFlag)
					mEnvstate = FASTRELEASE;
				else
					mEnvstate = RELEASE;
			}
		}
		
		
		outx = 0;
		
		for( ; mProcessFrac >= 0; mProcessFrac -= 21168 )
		{
			
		//--
		{
			int cnt = mEnvcnt;
			
			envx = mEnvx;
			/*
			switch (GetState()) {
				case kNoteState_FastReleased:
				case kNoteState_Released:
					mEnvstate = RELEASE;
					break;
				default:
					break;
			}
			 */
			switch( mEnvstate )
			{
				case ATTACK:
					if ( reg_ar == 15 )
					{
						envx += 0x400;
					}
					else
					{
						cnt -= ENVCNT[ ( reg_ar << 1 ) + 1 ];
						if( cnt > 0 )
						{
							break;
						}
						envx += 0x20;       /* 0x020 / 0x800 = 1/64         */
						cnt = CNT_INIT;
					}
					
					if( envx > 0x7FF )
					{
						envx = 0x7FF;
						mEnvstate = DECAY;
					}
					
					mEnvx = envx;
					break;
					
				case DECAY:
					cnt -= ENVCNT[ reg_dr*2 + 0x10 ];
					if( cnt <= 0 )
					{
						cnt = CNT_INIT;
						envx -= ( ( envx - 1 ) >> 8 ) + 1;
						mEnvx = envx;
					}
						
					if( envx <= 0x100 * ( reg_sl + 1 ) )
					{
						mEnvstate = SUSTAIN;
					}
					break;
					
				case SUSTAIN:
					cnt -= ENVCNT[ reg_sr ];
					if( cnt > 0 )
					{
						break;
					}
						cnt = CNT_INIT;
					envx -= ( ( envx - 1 ) >> 8 ) + 1;
					
					mEnvx = envx;
					
					break;
					
				case RELEASE:
					envx -= 0x8;
					if( envx <= 0 )
					{
						envx = -1;
					}
					else {
						mEnvx = envx;
					}
					break;
					
				case FASTRELEASE:
					envx -= 0x100;
					if( envx <= 0 )
					{
						envx = -1;
					}
					else {
						mEnvx = envx;
					}
					break;
			}
			mEnvcnt = cnt;
		}
		
		if( envx < 0 )
		{
			outx = 0;
			if (endFrame == 0xFFFFFFFF) endFrame = frame;
			continue;
		}
		
		//ピッチの算出
		pitch = (mPitch + pb)&0x3fff;
		
		if (reg_pmod == true)
		{
			mVibPhase += vibfreq;
			if (mVibPhase > onepi) mVibPhase -= onepi*2;
			
			float x2=mVibPhase*mVibPhase;
			float vibwave = 7.61e-03f;
			vibwave *= x2;
			vibwave -= 1.6605e-01f;
			vibwave *= x2;
			vibwave += 1.0f;
			vibwave *= mVibPhase;
			
			outx = (vibwave*vibdepth2)*VELOCITY_CURB[vibdepth];
			
			pitch = ( pitch * ( outx + 32768 ) ) >> 15;
			if (pitch <= 0) pitch=1;
		}
		
		for( ; mMixfrac >= 0; mMixfrac -= 4096 )
		{
			if( !mHeaderCnt )	//ブロックの始まり
			{
				if( mEnd & 1 )	//データ終了フラグあり
				{
					//if( mEnd & 2 )	//ループフラグあり
					if( mLoop )
					{
						mMemPtr = mLoopPoint;	//読み出し位置をループポイントまで戻す
					}
					else	//ループなし
					{
						if (endFrame == 0xFFFFFFFF) endFrame = frame;	//キー状態をオフにする
						mEnvx = 0;
						while( mMixfrac >= 0 )
						{
							mSampbuf[mSampptr] = 0;
							outx = 0;
							mSampptr  = ( mSampptr + 1 ) & 3;
							mMixfrac -= 4096;
						}
						break;
					}
				}
				
				//開始バイトの情報を取得
				mHeaderCnt = 8;
				vl = ( unsigned char )brrdata[mMemPtr++];
				mRange = vl >> 4;
				mEnd = vl & 3;
				mFilter = ( vl & 12 ) >> 2;
			}
			
			if( mHalf == 0 )
			{
				mHalf = 1;
				outx = ( ( signed char )brrdata[ mMemPtr ] ) >> 4;
			}
			else
			{
				mHalf = 0;
				outx = ( signed char )( brrdata[ mMemPtr++ ] << 4 );
				outx >>= 4;
				mHeaderCnt--;
			}
			//outx:4bitデータ
			
			if( mRange <= 0xC )
			{
				outx = ( outx << mRange ) >> 1;
			}
			else
			{
				outx &= ~0x7FF;
			}
			//outx:4bitデータ*Range
			
			switch( mFilter )
			{
				case 0:
					break;
					
				case 1:
					outx += filter1(mSmp1);
					break;
					
				case 2:
					outx += filter2(mSmp1,mSmp2);
					break;
					
				case 3:
					outx += filter3(mSmp1,mSmp2);
					break;
			}
			
			if( outx < -32768 )
			{
				outx = -32768;
			}
			else if( outx > 32767 )
			{
				outx = 32767;
			}
			if (clipper) {
				mSmp2 = ( signed short )mSmp1;
				mSmp1 = ( signed short )( outx << 1 );
				mSampbuf[mSampptr] = ( signed short )mSmp1;
			}
			else {
				mSmp2 = mSmp1;
				mSmp1 = outx << 1;
				mSampbuf[mSampptr] = mSmp1;
			}
			mSampptr = ( mSampptr + 1 ) & 3;
		}
		
		vl = mMixfrac >> 4;
		vr = ( ( G4[ -vl ] * mSampbuf[ mSampptr ] ) >> 11 ) & ~1;
		vr += ( ( G3[ -vl ]
				  * mSampbuf[ ( mSampptr + 1 ) & 3 ] ) >> 11 ) & ~1;
		vr += ( ( G2[ vl ]
				  * mSampbuf[ ( mSampptr + 2 ) & 3 ] ) >> 11 ) & ~1;
		
		if (clipper) {
			vr = ( signed short )vr;
		}
		vr += ( ( G1[ vl ]
				  * mSampbuf[ ( mSampptr + 3 ) & 3 ] ) >> 11 ) & ~1;
		
		if( vr > 32767 )
		{
			vr = 32767;
		}
		else if( vr < -32768 )
		{
			vr = -32768;
		}
		outx = vr;
		
		mMixfrac += pitch;
		
		outx = ( ( outx * envx ) >> 11 ) & ~1;
		outx = ( outx * mVelo ) >> 11;
		
		mProcessbuf[mProcessbufPtr]=outx;
		mProcessbufPtr=(mProcessbufPtr+1)&0x0f;
		}
		//--
		//16pointスプライン補間
		{
			int inputFrac = mProcessFrac+21168;
			int tabidx1 = ( inputFrac/1323 ) << 4;
			int tabidx2 = tabidx1 + 16;
			int a1 = 0, a2 = 0;
			for (int i=0; i<4; i++) {
				a1 += sinctable[tabidx1++] * mProcessbuf[mProcessbufPtr] >> 15;
				a2 += sinctable[tabidx2++] * mProcessbuf[mProcessbufPtr] >> 15;
				mProcessbufPtr=(mProcessbufPtr+1)&0x0f;
				a1 += sinctable[tabidx1++] * mProcessbuf[mProcessbufPtr] >> 15;
				a2 += sinctable[tabidx2++] * mProcessbuf[mProcessbufPtr] >> 15;
				mProcessbufPtr=(mProcessbufPtr+1)&0x0f;
				a1 += sinctable[tabidx1++] * mProcessbuf[mProcessbufPtr] >> 15;
				a2 += sinctable[tabidx2++] * mProcessbuf[mProcessbufPtr] >> 15;
				mProcessbufPtr=(mProcessbufPtr+1)&0x0f;
				a1 += sinctable[tabidx1++] * mProcessbuf[mProcessbufPtr] >> 15;
				a2 += sinctable[tabidx2++] * mProcessbuf[mProcessbufPtr] >> 15;
				mProcessbufPtr=(mProcessbufPtr+1)&0x0f;
			}
			outx = a1 + ( (( a2 - a1 ) * ( inputFrac % 1323 )) / 1323 );
		}
		//--
		//ボリューム値の反映
		vl = ( reg_vol_l * outx ) >> 7;
		vr = ( reg_vol_r * outx ) >> 7;
		
		left[frame] += vl / 32768.0f;
		if (right) right[frame] += vr / 32768.0f;
		
		mProcessFrac += procstep;
	}
	if (endFrame != 0xFFFFFFFF)
	{
		NoteEnded(endFrame);
	}

	return noErr;
}
