/*
 *  Chip700Note.h
 *  Chip700
 *
 *  Created by 開発用 on 06/09/06.
 *  Copyright 2006 __MyCompanyName__. All rights reserved.
 *
 */

#include "AUInstrumentBase.h"
#include "Chip700Version.h"

#ifndef __Chip700Note_h__
#define __Chip700Note_h__

typedef enum
{
    ATTACK,
    DECAY,
    SUSTAIN,
    RELEASE
} env_state_t32;


struct Chip700Note : public SynthNote
{
	virtual					~Chip700Note() {}
	virtual void			Reset();
	
	virtual void			Attack(const MusicDeviceNoteParams &inParams);
	virtual void			Kill(UInt32 inFrame);
	virtual void			Release(UInt32 inFrame);
	virtual void			FastRelease(UInt32 inFrame);
	virtual Float32			Amplitude() { return mEnvx; }
	virtual OSStatus		Render(UInt32 inNumFrames, AudioBufferList& inBufferList);
	
	int						AdvanceEnvelope(UInt32 vstate);
	int						VibratoEnvelope(int mode, int t);
	
	
	SInt32			mVelo;
	bool			mKeyOn,mKeyOff;
	UInt32			mLoopPoint;
	bool			mLoop;
	double			mCFreq;
	unsigned char	*brrdata;
	
	int				mNoiseCnt;
	int				mNoiseLev;
	float			mVibPhase;
	int				mVibEnvx;
	int				mVibEnvcnt;
	
	int				mMemPtr;        /* Sample data memory pointer   */
	int             mEnd;            /* End or loop after block      */
	int             mEnvcnt;         /* Counts to envelope update    */
	env_state_t32   mEnvstate;       /* Current envelope state       */
	int             mEnvx;           /* Last env height (0-0x7FFF)   */
	int             mFilter;         /* Last header's filter         */
	int             mHalf;           /* Active nybble of BRR         */
	int             mHeaderCnt;     /* Bytes before new header (0-8)*/
	int             mMixfrac;        /* Fractional part of smpl pstn */	//サンプル間を4096分割した位置
//	int             mOnCnt;         /* Is it time to turn on yet?   */
	int             mPitch;          /* Sample pitch (4096->32000Hz) */
	int             mRange;          /* Last header's range          */
//	unsigned long   mSamp_id;        /* Sample ID#                   */
	int             mSampptr;        /* Where in sampbuf we are      */
	signed long     mSmp1;           /* Last sample (for BRR filter) */
	signed long     mSmp2;           /* Second-to-last sample decoded*/
	signed long     mSampbuf[4];   /* Buffer for Gaussian interp   */
	
	int		reg_envx,reg_outx,reg_vol_l,reg_vol_r,reg_ar,reg_dr,reg_sl,reg_sr,reg_flg;
	bool	reg_noise,reg_pmod,reg_endx;
};

#endif
