#include <stdio.h>
#include <math.h>

int main(void)
{
    int i,j;
    double  v;
    int     iv;
    
    for (j=0; j<8; j++) {
     for (i=0; i<16; i++) { 
        v= 2047*pow((double)(j*16+i)/127.0,3.0);
        iv = v;
         printf("0x%03x, ",iv);
    }
    putchar('\n');
    }
}
